export class Student {
    constructor(public sid : number,
        public name : string,
        public city : string,
        public cgp : number
        ) {}
}
