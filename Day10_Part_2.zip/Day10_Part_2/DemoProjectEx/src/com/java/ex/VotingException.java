package com.java.ex;

public class VotingException extends Exception {

	public VotingException() {} 
	
	public VotingException(String error) {
		super(error);
	}
}


