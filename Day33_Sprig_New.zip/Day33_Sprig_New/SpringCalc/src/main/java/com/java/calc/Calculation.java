package com.java.calc;

public interface Calculation {

	int sum();
	int sub();
	int mult();
}
