package com.java.name;

public interface Name {

	String fullName();
}
