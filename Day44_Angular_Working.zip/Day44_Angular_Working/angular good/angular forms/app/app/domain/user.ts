export class User { 
    userName: string;
	gender: string;
	isMarried: boolean = false;
	isTCAccepted: boolean;
    constructor() {
    }
} 