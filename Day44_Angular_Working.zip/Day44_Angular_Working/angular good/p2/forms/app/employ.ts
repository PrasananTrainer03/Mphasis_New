export class Employ {
    constructor() { }
    private empno : number;
    private name : string;
    private dept : string;
    private desig : string;
    private basic : number;
}
