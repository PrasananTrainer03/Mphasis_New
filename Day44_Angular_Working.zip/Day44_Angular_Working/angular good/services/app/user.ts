export class User {
    public id : number;
    public name : string;
    public username : string;
    public email : string;
    constructor() {
    }
}
