export class Emp {
    public Empno : number;
    public nam : string;
    public dept : string;
    public desig : string;
    public basic : number;
    constructor() {

    }
}
