package com.java.day2;

public class EmployShow {

	public static void main(String[] args) {
		Emp emp = new Emp();
		emp.empno=1;
		emp.name="Vallabh";
		emp.basic=88255;
		
		System.out.println(emp);
	
	}
}
