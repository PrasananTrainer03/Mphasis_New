package com.java.day2;

public class Customer {

	int custId;
	String name;
	double billAmount;
	String city;
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", billAmount=" + billAmount + ", city=" + city + "]";
	}
	
	
}
