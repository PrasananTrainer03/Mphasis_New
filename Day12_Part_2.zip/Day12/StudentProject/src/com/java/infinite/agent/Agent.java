package com.java.infinite.agent;

public class Agent {

	private int agentId;
	private String name;
	private String city;
	private Gender gender;
	private double premium;
}
