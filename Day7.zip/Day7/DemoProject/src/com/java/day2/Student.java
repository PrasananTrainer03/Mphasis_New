package com.java.day2;

public class Student {

	int sno;
	String sname;
	double cgp;
}
