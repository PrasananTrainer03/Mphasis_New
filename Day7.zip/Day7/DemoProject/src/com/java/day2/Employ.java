package com.java.day2;

public class Employ {

	int empno;
	String name;
	double basic;
}
