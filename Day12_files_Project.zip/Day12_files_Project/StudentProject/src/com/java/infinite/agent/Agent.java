package com.java.infinite.agent;

public class Agent {

	private int agentId;
	private String name;
	private String city;
	private Gender gender;
	private double premium;
	
	// AgentId not negative or zero
//	name and city min 3 chars
	//premium min 1000 rs
	
	// Perform CRUD operations 
	//Show Agent, Search Agent, Add Agent, Update Agent, Delete Agent
}
