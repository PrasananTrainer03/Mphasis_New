package com.java.infinite.agent;

public enum Gender {
	MALE, FEMALE
}
