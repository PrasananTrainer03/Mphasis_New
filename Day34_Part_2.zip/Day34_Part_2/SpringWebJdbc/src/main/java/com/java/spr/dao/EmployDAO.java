package com.java.spr.dao;

import java.util.List;

import com.java.spr.model.Employ;

public interface EmployDAO {

	List<Employ> list();
}
