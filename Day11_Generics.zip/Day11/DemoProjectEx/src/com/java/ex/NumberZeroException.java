package com.java.ex;

public class NumberZeroException extends Exception {

	public NumberZeroException() {}
	
	public NumberZeroException(String error) {
		super(error);
	}
}
