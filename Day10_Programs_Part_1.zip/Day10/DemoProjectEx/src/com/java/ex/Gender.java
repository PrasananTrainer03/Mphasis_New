package com.java.ex;

public enum Gender {

	MALE, FEMALE
}
