package com.java.ex;

enum Month {
	JANUARY,
	FEBRUARY,MARCH,APRIL,MAY,JUNE,JULY,AUGUST,SEPTEMBER,
	OCTOBER, NOVEMBER,DECEMBER
}
public class EnumEx2 {

	public static void main(String[] args) {
		Month month = Month.OCTOBER;
		System.out.println(month);
	}
}
